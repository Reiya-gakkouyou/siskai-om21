

<?php $__env->startSection('content'); ?>
<form action="/Home" methods="POST">
    <?= csrf_field()?>
</form>
<div class="nav">
<ul class="nav nav-tabs">
    <h1>J-wel</h1>
  <li class="nav-item">

    <a class="nav-link"  href="http://192.168.10.10/Home">HOME</a>
  </li>
  <li class="nav-item">
    <a class="nav-link" href="#!">Link</a>
  </li>
  <li class="nav-item">
    <a class="nav-link" href="http://192.168.10.10/cart/list">cart</a>
  </li>
</ul>
</div>

<div class="contena">
<img class="main" src="/images/diamond.jpg">
</div>

<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>