
<?php $__env->startSection('content'); ?>
<form action="/order" method="POST">
    <?=csrf_field()?>
  <table class="table table-dark">
  <tr>
    <caption>oerderseet</caption>
    <td>名前：<input type="text" name="name" value="<?=$inputs["name"]??''?>"></td>
    <td>住所：<input type="text" name="address" value="<?=$inputs["name"]??''?>"></td>
    <td>電話番号：<input type="text" value="" name="tel"></td>
    <td>Email：<input type="text" value="" name="email"></td>
    <td><input type="submit" value="注文"></td>
  </tr>
  </td>
</table>
</form>
<table class="table table-dark">
  <caption>oerderseet</caption>
  <thead>
    <tr>
      <th>#</th>
      <th scope="col">名前</th>
      ...
    </tr>
  </thead>
  <tbody>
    <tr>
      <th scope="row"><input type="text" name="name" value="<?=$inputs["name"]??''?>"></th>
      <td></td>
      ...
    </tr>
    ...
  </tbody>
</table>

<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>