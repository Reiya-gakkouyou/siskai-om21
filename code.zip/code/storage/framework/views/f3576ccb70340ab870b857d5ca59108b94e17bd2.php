<!DOCTYPE HTML>
<html lang="ja">

</form>

<head>
    <meta charset="UTF-8">
    <title>jewelry</title>
    <link rel="stylesheet" href="/css/app.css" />

    <link rel="stylesheet" href="/css/main.css" />
    <link rel="stylesheet" href="/css/ce.css" />

    </head>

    <body>

    <div class="super_container">



</head>
<body>
</div>
    <?php echo $__env->yieldContent('content'); ?>
</body>
</html>


</form>
