

<?php $__env->startSection('content'); ?>
<div class="nav">
<ul class="nav nav-tabs">
    <h1>カート内の商品</h1>
  <li class="nav-item">

    <a class="nav-link" href="http://192.168.10.10/Home">HOME</a>
  </li>
  <li class="nav-item">
    <a class="nav-link" href="#!">Link</a>
  </li>
  <li class="nav-item">
    <a class="nav-link" href="http://192.168.10.10/cart/list">cart</a>
  </li>
</ul>
</div>

  <div class="container d-flex">
<form action="/cart/delete" method="post">
  <?= csrf_field()?>
  <input type="submit" value="カートすべて消去">
</form>
<form action="/cart" method="post">
  <?= csrf_field()?>
  <input type="submit" value="shopに戻る">
</form>
</div>

  <div class="container d-flex flex-wrap">
<?php foreach($cartItems as $index => $item): ?>
  <div class="card small">
    <div class="sal">
    <div class="card-header">
      <h2 class="card-title"><a href="/item/<?=$item->id?>"><?=$item->name?></a></h1>
    </div>
    <div class="card-body">
      <img class="card-img-top" src="<?=$item->img?>" />
    </div>

    <div class="card-footer">
      <p class="Appraisal"><?=$item->Appraisal?></p>
      <p class="price">￥<?=$item->price?></p>
      <form action="/cart_delete" method="post">
        <input type="hidden" name="cart_index" value="<?=$index?>">
        <?= csrf_field()?>
        <input type="submit" value="カートから消去">
      </form>
    </div>
  </div>
  </div>

  <?php endforeach; ?>
</div>

<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>