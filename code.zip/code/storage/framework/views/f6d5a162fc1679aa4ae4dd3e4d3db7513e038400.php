

<?php $__env->startSection('content'); ?>
<div class="nav">
<ul class="nav nav-tabs">
    <h1 class="rogo">Shop</h1>
  <li class="nav-item">

    <a class="nav-link" href="http://192.168.10.10/Home">HOME</a>
  </li>
  <li class="nav-item">
    <a class="nav-link" href="#!">Link</a>
  </li>
  <li class="nav-item">
    <a class="nav-link" href="http://192.168.10.10/cart/list">cart</a>
  </li>
</ul>
</div>

<div class="container d-flex">
<?php foreach($items as $item): ?>
<div class="card small">
  <div class="sal">
  <div class="card-header">
    <h2 class="card-title"><a href="/item/<?=$item->id?>"><?=$item->name?></a></h1>
  </div>
  <div class="card-body">
    <img class="card-img-top" src="<?=$item->img?>" />
  </div>

  <form class="card-footer" action="/cart/add" method="post">
    <?= csrf_field()?>
    <input type="hidden" name="item_id" value="<?=$item->id?>">
    <p class="Appraisal"><?=$item->Appraisal?></p>
    <p class="price">￥<?=$item->price?></p>
    <input class="mx-auto" type="submit" value="カートに追加">
  </form>
</div>
</div>
<?php endforeach; ?>

</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>